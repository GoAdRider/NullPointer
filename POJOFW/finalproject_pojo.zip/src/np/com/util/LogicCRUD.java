package np.com.util;

public interface LogicCRUD {
}
