package np.mem.model;

public class test {
	
	public static void main(String[] args) {
		int a= 14;
	
//		System.out.println(a/4);
		for(int i=1;i<a;i++) {
//			for(int j=0;j<4;j++) {
//				System.out.print();
//			}
			if(i%4==1) {
				System.out.println("");
			}
			System.out.print(i);
		}
	}
}