package np.com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.google.gson.Gson;

import np.com.util.HashMapBinder;
import np.mem.model.CookClassDao;

//cookclass/*.np
public class CookClassController implements Action{
	Logger logger = Logger.getLogger(CookClassController.class);

	public ModelAndView execute(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		ModelAndView mav = new ModelAndView(req, res);
		PrintWriter out = res.getWriter();
		String pageName = (String)req.getAttribute("pageName");
		CookClassDao cookClassDao = CookClassDao.getInstance();
		
		Gson g = null;
	    Map<String,Object> pmap = new HashMap<>();
		HashMapBinder hmb = new HashMapBinder(req);
		hmb.bind(pmap);
		
		String forJson = null;
		
		logger.info("CookClassC map>>>>>>"+pmap);
		
		if(pageName.equals("createClass")) {	//쿠킹 클래스 생성 (셰프전용)
			pmap.put("field","OPEN_COOKCLASS");
			String msg= cookClassDao.cookingClass(pmap);
			logger.info("CookClassC - createClass"+msg);
			mav.addObject("msg", msg);
		}
		else if(pageName.equals("joinClass")) {		//쿠킹 클래스 참가
			pmap.put("field","ATTEND_COOKCLASS");
			String msg= cookClassDao.cookingClass(pmap);
			logger.info("CookClassC - joinClass"+msg);
			mav.addObject("msg", msg);
		}
		else if(pageName.equals("updClass")) {		//쿠킹 클래스 수정(셰프전용)
			pmap.put("field","UPD_COOKCLASS");
			String msg= cookClassDao.cookingClass(pmap);
			logger.info("CookClassC - joinClass"+msg);
			mav.addObject("msg", msg);
		}
		else if(pageName.equals("cancelClass")) {		//쿠킹클래스 삭제 or 취소
			String msg= cookClassDao.cancelClass(pmap);
			logger.info("CookClassC - cancelClass"+msg);
			mav.addObject("msg", msg);
		}
		else if(pageName.equals("showClass")) {		//쿠킹클래스 전부 보기
			List<Map<String, Object>> list = cookClassDao.showClass(pmap);
			logger.info("CookClassC - showClass"+list);
	        g = new Gson();
	        forJson = g.toJson(list);
		}
		else if(pageName.equals("myClassMemList")) {		// 내 쿠킹클래스 전체의 신청 회원 보기
			pmap.put("field","SHOW_APPLY_USERS");
			pmap.put("c_classcd","");
			pmap.put("m_id","");
			List<Map<String, Object>> list = cookClassDao.classForChef(pmap);
			logger.info("CookClassC - myClassMemList"+list);
			g = new Gson();
			forJson = g.toJson(list);
		}
		else if(pageName.equals("myClassMemAccept")) {		//쿠킹클래스 회원 수락
			pmap.put("field","ACCEPT_MYCLASS");
			List<Map<String, Object>> list = cookClassDao.classForChef(pmap);
			String msg = null;
			for(Map<String,Object> rmap : list) {
				msg = (String)rmap.get("MSG");//String으로 받기
			}
			logger.info("CookClassC - myClassMemAccept"+msg);
			mav.addObject("msg", msg);
		}
		else if(pageName.equals("myClassMemDeny")) {		//쿠킹클래스 회원 반려
			pmap.put("field","DENY_MYCLASS");
			List<Map<String, Object>> list = cookClassDao.classForChef(pmap);
			String msg = null;
			for(Map<String,Object> rmap : list) {
				msg = (String)rmap.get("MSG");//String으로 받기
			}
			logger.info("CookClassC - myClassMemDeny"+msg);
			mav.addObject("msg", msg);
		}

		
		
		if(g == null) {
			mav.setViewName(pageName+".jsp");
		}else {
			res.setContentType("application/json; charset=utf-8");
			out.print(forJson);
		}
		
		return mav;
	}
}
